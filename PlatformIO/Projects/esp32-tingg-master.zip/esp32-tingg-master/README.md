# esp32-tingg
This repository contains different examples for the ESP32 that can be used with the tingg.io IoT platform.
