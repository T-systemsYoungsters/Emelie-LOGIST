char networkSSID[] = "YOUR_WIFI_SSID";
char networkPASSWORD[] = "YOUR_WIFI_PASSWORD";

char mqttSERVER[] = "mqtt.tingg.io";
char mqttUSERNAME[] = "thing";
char thingID[] = "YOUR_THING_ID";
char thingKEY[] = "YOUR_THING_KEY";
